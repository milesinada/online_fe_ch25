import "./navBar.css"

const NavBar = () =>{
    return(
        <div className="navbar">
            <h1>NavBar will be here</h1>
        </div>
    );
}

export default NavBar;